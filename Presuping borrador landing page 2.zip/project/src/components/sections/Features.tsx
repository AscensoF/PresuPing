import React, { useEffect, useRef } from 'react';
import { Smartphone, PieChart, Lightbulb, Target, ArrowUpRight, Clock, Shield } from 'lucide-react';
import { Card } from '../ui/Card';

const features = [
  {
    icon: <Smartphone size={32} />,
    title: 'Fácil de Usar',
    description: 'Sin apps adicionales, gestiona todo directamente en WhatsApp con comandos simples.'
  },
  {
    icon: <Lightbulb size={32} />,
    title: 'Sin Tecnicismos',
    description: 'Explicaciones claras, ejemplos cotidianos y lenguaje simple para entender tus finanzas.'
  },
  {
    icon: <Target size={32} />,
    title: 'Seguimiento Simple',
    description: 'Visualiza tu progreso de forma clara y motivadora con informes periódicos.'
  },
  {
    icon: <PieChart size={32} />,
    title: 'Categorización Automática',
    description: 'Tus gastos se categorizan automáticamente para identificar patrones de consumo.'
  },
  {
    icon: <Clock size={32} />,
    title: 'Recordatorios Inteligentes',
    description: 'Recibe alertas para pagos recurrentes y objetivos financieros.'
  },
  {
    icon: <Shield size={32} />,
    title: 'Privacidad Asegurada',
    description: 'Tus datos financieros están seguros y nunca se comparten con terceros.'
  }
];

export function Features() {
  const featuresRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry, index) => {
          if (entry.isIntersecting) {
            setTimeout(() => {
              entry.target.classList.add('opacity-100', 'translate-y-0');
              entry.target.classList.remove('opacity-0', 'translate-y-12');
            }, index * 100);
          }
        });
      },
      { threshold: 0.1 }
    );
    
    const elements = featuresRef.current?.querySelectorAll('.feature-card');
    elements?.forEach(el => observer.observe(el));
    
    return () => observer.disconnect();
  }, []);
  
  return (
    <section id="características" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">¿Por qué PresuPing?</h2>
          <p className="text-lg text-gray-600">
            Nuestro enfoque único te permite gestionar tu dinero sin complicaciones,
            directamente en la app que usas todos los días.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" ref={featuresRef}>
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="feature-card opacity-0 translate-y-12 transition-all duration-700"
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <Card 
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
              />
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <a 
            href="#" 
            className="inline-flex items-center text-[#25D366] font-medium hover:underline group"
          >
            Ver todas las características 
            <ArrowUpRight 
              size={16} 
              className="ml-1 transition-transform group-hover:translate-x-1" 
            />
          </a>
        </div>
      </div>
    </section>
  );
}