import React, { useEffect, useRef } from 'react';
import { Button } from '../ui/Button';

export function Hero() {
  const heroRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('opacity-100', 'translate-y-0');
            entry.target.classList.remove('opacity-0', 'translate-y-8');
          }
        });
      },
      { threshold: 0.1 }
    );
    
    const elements = heroRef.current?.querySelectorAll('.animate-on-scroll');
    elements?.forEach(el => observer.observe(el));
    
    return () => observer.disconnect();
  }, []);
  
  return (
    <section id="inicio" className="relative bg-gradient-to-r from-[#25D366] to-[#128C7E] min-h-screen flex items-center pt-20">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -right-40 -bottom-40 w-96 h-96 bg-white opacity-10 rounded-full"></div>
        <div className="absolute -left-20 top-40 w-64 h-64 bg-white opacity-10 rounded-full"></div>
      </div>
      
      <div className="container mx-auto px-4 py-20 relative z-10" ref={heroRef}>
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 animate-on-scroll opacity-0 translate-y-8 transition-all duration-700">
              Controla tus finanzas desde WhatsApp
            </h1>
            <p className="text-xl text-white/90 mb-8 animate-on-scroll opacity-0 translate-y-8 transition-all duration-700 delay-200">
              Gestiona tu dinero de forma simple, sin complicaciones y directamente desde tu app favorita de mensajería. Sin apps adicionales, sin curva de aprendizaje.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 animate-on-scroll opacity-0 translate-y-8 transition-all duration-700 delay-400">
              <Button 
                variant="secondary" 
                size="lg"
                onClick={() => document.getElementById('contacto')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Empezar Ahora
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="border-white text-white hover:bg-white hover:text-[#25D366]"
              >
                Ver Demo
              </Button>
            </div>
          </div>
          
          <div className="animate-on-scroll opacity-0 translate-y-8 transition-all duration-700 delay-600">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-[#25D366]/30 to-[#128C7E]/30 rounded-3xl transform rotate-3"></div>
              <img 
                src="https://images.pexels.com/photos/7709197/pexels-photo-7709197.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="PresuPing en WhatsApp" 
                className="rounded-3xl shadow-2xl relative z-10 transform -rotate-3 transition-transform duration-500 hover:rotate-0"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}