import React, { useEffect, useRef } from 'react';

const steps = [
  {
    number: '01',
    title: 'Agrega nuestro contacto',
    description: 'Simplemente agrega nuestro número a tus contactos en WhatsApp y envía un mensaje para comenzar.'
  },
  {
    number: '02',
    title: 'Registra tus ingresos y gastos',
    description: 'Envía mensajes con tus transacciones utilizando comandos simples como "gasto" o "ingreso".'
  },
  {
    number: '03',
    title: 'Recibe informes personalizados',
    description: 'Obtén resúmenes semanales y mensuales de tu situación financiera con consejos personalizados.'
  },
  {
    number: '04',
    title: 'Mejora tus finanzas',
    description: 'Identifica patrones de gasto, establece objetivos y toma mejores decisiones financieras.'
  }
];

export function HowItWorks() {
  const stepsRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const elements = entry.target.querySelectorAll('.step-item');
            elements.forEach((el, index) => {
              setTimeout(() => {
                el.classList.add('opacity-100', 'translate-x-0');
                el.classList.remove('opacity-0', 'translate-x-12');
              }, index * 200);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    
    if (stepsRef.current) {
      observer.observe(stepsRef.current);
    }
    
    return () => observer.disconnect();
  }, []);
  
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">¿Cómo funciona?</h2>
          <p className="text-lg text-gray-600">
            Empezar a utilizar PresuPing es tan sencillo como enviar un mensaje de WhatsApp.
            Sin descargas, sin registros complicados.
          </p>
        </div>
        
        <div className="relative" ref={stepsRef}>
          <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-0.5 bg-[#25D366]/30"></div>
          
          {steps.map((step, index) => (
            <div 
              key={index} 
              className="step-item opacity-0 translate-x-12 transition-all duration-700 relative mb-12 md:mb-24 last:mb-0"
            >
              <div className="flex flex-col md:flex-row items-start md:items-center gap-8">
                <div className="md:w-1/2 md:text-right md:pr-12">
                  {index % 2 === 0 ? (
                    <>
                      <span className="inline-block text-5xl font-bold text-[#25D366]/20 mb-2">{step.number}</span>
                      <h3 className="text-2xl font-bold mb-3">{step.title}</h3>
                      <p className="text-gray-600">{step.description}</p>
                    </>
                  ) : (
                    <div className="hidden md:block">
                      <div className="bg-gray-100 rounded-xl p-6 inline-block">
                        <img 
                          src={`https://images.pexels.com/photos/${4000 + index}/pexels-photo-${4000 + index}.jpeg?auto=compress&cs=tinysrgb&w=600`} 
                          alt={step.title} 
                          className="rounded-lg w-64 h-auto"
                        />
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="hidden md:flex items-center justify-center relative">
                  <div className="w-12 h-12 rounded-full bg-[#25D366] text-white flex items-center justify-center z-10">
                    {index + 1}
                  </div>
                </div>
                
                <div className="md:w-1/2 md:pl-12">
                  {index % 2 === 1 ? (
                    <>
                      <span className="inline-block text-5xl font-bold text-[#25D366]/20 mb-2">{step.number}</span>
                      <h3 className="text-2xl font-bold mb-3">{step.title}</h3>
                      <p className="text-gray-600">{step.description}</p>
                    </>
                  ) : (
                    <div className="hidden md:block">
                      <div className="bg-gray-100 rounded-xl p-6 inline-block">
                        <img 
                          src={`https://images.pexels.com/photos/${5000 + index}/pexels-photo-${5000 + index}.jpeg?auto=compress&cs=tinysrgb&w=600`} 
                          alt={step.title} 
                          className="rounded-lg w-64 h-auto"
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}