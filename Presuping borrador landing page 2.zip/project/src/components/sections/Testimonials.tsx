import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: 'María Rodríguez',
    role: 'Enfermera',
    quote: 'PresuPing cambió completamente la forma en que manejo mi dinero. Ahora puedo ver dónde va cada euro sin tener que instalar otra app más.',
    image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150',
    rating: 5
  },
  {
    id: 2,
    name: 'Juan Carlos Pérez',
    role: 'Profesor',
    quote: 'Nunca había podido mantener un presupuesto hasta que empecé a usar PresuPing. La simplicidad de enviar mensajes por WhatsApp hace que sea imposible olvidar registrar mis gastos.',
    image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150',
    rating: 5
  },
  {
    id: 3,
    name: 'Ana Martínez',
    role: 'Diseñadora Gráfica',
    quote: 'Como freelancer, necesitaba una forma sencilla de seguir mis gastos e ingresos. PresuPing es perfecta porque no necesito aprender a usar un software complicado.',
    image: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
    rating: 4
  },
  {
    id: 4,
    name: 'Miguel Ángel López',
    role: 'Estudiante',
    quote: 'Con un presupuesto ajustado de estudiante, necesitaba algo que me ayudara a no gastar de más. Los recordatorios de PresuPing me han salvado más de una vez.',
    image: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=150',
    rating: 5
  }
];

export function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const slideRef = useRef<HTMLDivElement>(null);
  
  const nextSlide = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };
  
  const prevSlide = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };
  
  useEffect(() => {
    if (slideRef.current) {
      slideRef.current.addEventListener('transitionend', () => {
        setIsAnimating(false);
      });
    }
    
    const interval = setInterval(() => {
      nextSlide();
    }, 6000);
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <section className="py-20 bg-white overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Lo que dicen nuestros usuarios</h2>
          <p className="text-lg text-gray-600">
            Miles de personas ya han mejorado sus finanzas con PresuPing.
            Estas son algunas de sus experiencias.
          </p>
        </div>
        
        <div className="relative max-w-5xl mx-auto">
          <div 
            className="flex transition-transform duration-500 ease-in-out"
            style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            ref={slideRef}
          >
            {testimonials.map((testimonial) => (
              <div 
                key={testimonial.id} 
                className="w-full flex-shrink-0 px-4"
              >
                <div className="bg-gray-50 rounded-2xl p-8 md:p-12 shadow-lg">
                  <div className="flex flex-col md:flex-row md:items-center gap-6">
                    <div className="flex-shrink-0">
                      <img 
                        src={testimonial.image} 
                        alt={testimonial.name} 
                        className="w-20 h-20 rounded-full object-cover"
                      />
                    </div>
                    
                    <div>
                      <div className="flex mb-3">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i}
                            size={18}
                            className={i < testimonial.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}
                          />
                        ))}
                      </div>
                      
                      <blockquote className="text-xl italic mb-6">
                        "{testimonial.quote}"
                      </blockquote>
                      
                      <div>
                        <p className="font-bold">{testimonial.name}</p>
                        <p className="text-sm text-gray-600">{testimonial.role}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <button 
            onClick={prevSlide}
            disabled={isAnimating}
            className="absolute top-1/2 -translate-y-1/2 left-0 md:-left-12 w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center text-gray-600 hover:text-[#25D366] disabled:opacity-50 transition-colors"
            aria-label="Anterior testimonio"
          >
            <ChevronLeft size={20} />
          </button>
          
          <button 
            onClick={nextSlide}
            disabled={isAnimating}
            className="absolute top-1/2 -translate-y-1/2 right-0 md:-right-12 w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center text-gray-600 hover:text-[#25D366] disabled:opacity-50 transition-colors"
            aria-label="Siguiente testimonio"
          >
            <ChevronRight size={20} />
          </button>
          
          <div className="flex justify-center space-x-2 mt-8">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-2.5 h-2.5 rounded-full transition-colors ${
                  index === currentIndex ? 'bg-[#25D366]' : 'bg-gray-300'
                }`}
                aria-label={`Ver testimonio ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}