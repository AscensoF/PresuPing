import React, { useState } from 'react';
import { Send, Check } from 'lucide-react';
import { Input, TextArea } from '../ui/Input';
import { Button } from '../ui/Button';

interface FormState {
  name: string;
  email: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  message?: string;
}

export function ContactForm() {
  const [formState, setFormState] = useState<FormState>({
    name: '',
    email: '',
    message: ''
  });
  
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};
    
    if (!formState.name.trim()) {
      newErrors.name = 'El nombre es requerido';
    }
    
    if (!formState.email.trim()) {
      newErrors.email = 'El email es requerido';
    } else if (!/^\S+@\S+\.\S+$/.test(formState.email)) {
      newErrors.email = 'Email inválido';
    }
    
    if (!formState.message.trim()) {
      newErrors.message = 'El mensaje es requerido';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      setIsSubmitting(true);
      
      // Simulate API call
      setTimeout(() => {
        setIsSubmitting(false);
        setIsSubmitted(true);
        
        // Reset form after showing success message
        setTimeout(() => {
          setFormState({ name: '', email: '', message: '' });
          setIsSubmitted(false);
        }, 3000);
      }, 1500);
    }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormState(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name as keyof FormErrors]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };
  
  return (
    <section id="contacto" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Comienza ahora con PresuPing</h2>
            <p className="text-lg text-gray-600">
              Completa el formulario y te contactaremos para ayudarte a comenzar tu viaje hacia una mejor salud financiera.
            </p>
          </div>
          
          <div className="bg-white rounded-2xl shadow-xl p-8">
            {isSubmitted ? (
              <div className="text-center py-8">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                  <Check className="text-[#25D366]" size={32} />
                </div>
                <h3 className="text-2xl font-bold mb-2">¡Mensaje enviado!</h3>
                <p className="text-gray-600">Nos pondremos en contacto contigo muy pronto.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <Input 
                  label="Nombre"
                  type="text"
                  name="name"
                  placeholder="Tu nombre"
                  value={formState.name}
                  onChange={handleChange}
                  error={errors.name}
                  required
                />
                
                <Input 
                  label="Email"
                  type="email"
                  name="email"
                  placeholder="tu@email.com"
                  value={formState.email}
                  onChange={handleChange}
                  error={errors.email}
                  required
                />
                
                <TextArea 
                  label="Mensaje"
                  name="message"
                  placeholder="Cuéntanos qué te gustaría saber sobre PresuPing..."
                  rows={4}
                  value={formState.message}
                  onChange={handleChange}
                  error={errors.message}
                  required
                />
                
                <Button 
                  type="submit"
                  fullWidth
                  size="lg"
                  disabled={isSubmitting}
                  className="flex items-center justify-center"
                >
                  {isSubmitting ? (
                    <span className="inline-block animate-spin rounded-full h-4 w-4 border-2 border-white/20 border-t-white"></span>
                  ) : (
                    <>
                      Enviar mensaje <Send className="ml-2" size={16} />
                    </>
                  )}
                </Button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}