import React, { useState, useEffect } from 'react';
import { MessageSquare } from 'lucide-react';
import { Button } from './ui/Button';

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled 
        ? 'bg-white shadow-md py-3' 
        : 'bg-transparent py-5'
    }`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <MessageSquare className={`mr-2 ${isScrolled ? 'text-[#25D366]' : 'text-white'}`} />
            <span className={`font-bold text-xl ${isScrolled ? 'text-gray-800' : 'text-white'}`}>
              PresuPing
            </span>
          </div>
          
          <nav className="hidden md:block">
            <ul className="flex space-x-8">
              {['Inicio', 'Características', 'Precios', 'Contacto'].map((item) => (
                <li key={item}>
                  <a 
                    href={`#${item.toLowerCase()}`}
                    className={`font-medium transition-colors ${
                      isScrolled ? 'text-gray-700 hover:text-[#25D366]' : 'text-white hover:text-white/80'
                    }`}
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
          
          <Button 
            variant={isScrolled ? 'primary' : 'secondary'} 
            size="sm"
          >
            Empezar Ahora
          </Button>
        </div>
      </div>
    </header>
  );
}