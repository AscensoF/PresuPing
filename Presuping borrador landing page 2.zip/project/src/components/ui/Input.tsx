import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
}

export function Input({ label, error, className = '', ...props }: InputProps) {
  return (
    <div className="space-y-2">
      <label className="block text-gray-700 font-medium">{label}</label>
      <input 
        className={`w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#25D366] focus:ring-2 focus:ring-[#25D366]/40 focus:outline-none transition-all duration-200 ${error ? 'border-red-500' : ''} ${className}`}
        {...props} 
      />
      {error && <p className="text-red-500 text-sm">{error}</p>}
    </div>
  );
}

interface TextAreaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  error?: string;
}

export function TextArea({ label, error, className = '', ...props }: TextAreaProps) {
  return (
    <div className="space-y-2">
      <label className="block text-gray-700 font-medium">{label}</label>
      <textarea 
        className={`w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#25D366] focus:ring-2 focus:ring-[#25D366]/40 focus:outline-none transition-all duration-200 ${error ? 'border-red-500' : ''} ${className}`}
        {...props} 
      />
      {error && <p className="text-red-500 text-sm">{error}</p>}
    </div>
  );
}