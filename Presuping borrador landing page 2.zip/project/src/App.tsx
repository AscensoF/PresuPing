import React, { useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/sections/Hero';
import { Features } from './components/sections/Features';
import { HowItWorks } from './components/sections/HowItWorks';
import { Testimonials } from './components/sections/Testimonials';
import { ContactForm } from './components/sections/ContactForm';
import { Footer } from './components/Footer';

function App() {
  useEffect(() => {
    // Update the document title
    document.title = 'PresuPing - Tu Presupuesto Personal en WhatsApp';
    
    // Set favicon to a more appropriate one
    const favicon = document.querySelector('link[rel="icon"]');
    if (favicon) {
      favicon.setAttribute('href', 'https://img.icons8.com/color/48/000000/whatsapp--v1.png');
    }
  }, []);

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main>
        <Hero />
        <Features />
        <HowItWorks />
        <Testimonials />
        <ContactForm />
      </main>
      <Footer />
    </div>
  );
}

export default App;